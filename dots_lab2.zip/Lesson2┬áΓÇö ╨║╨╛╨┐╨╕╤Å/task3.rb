require 'prime'
def firstNprimes(n)
  Prime.first n
end
p 'Проверка'
p firstNprimes(5)
p firstNprimes(1)
p firstNprimes(10)